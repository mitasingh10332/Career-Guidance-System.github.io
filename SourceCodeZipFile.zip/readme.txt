Our minor project is developed in django [backend framework written in python]

Instructions for running the project on your own device
1. Open the folder in any powershell by entering cd [path of this folder]
2. Now you are in Minor folder 
3. Run command python manage.py runserver
4. This will run the server and after you clicks on the link then you can interact with the project.
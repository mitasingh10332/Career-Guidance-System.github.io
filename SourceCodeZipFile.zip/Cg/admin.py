from django.contrib import admin

from Cg.models import *

# Register your models here.
admin.site.register(QuestionsFor10th)
admin.site.register(QuestionsFor12th)